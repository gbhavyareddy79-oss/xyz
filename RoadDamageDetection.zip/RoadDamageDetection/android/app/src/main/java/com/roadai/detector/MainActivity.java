package com.roadai.detector;

import android.Manifest;
import android.content.pm.PackageManager;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.*;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.FileProvider;

import com.bumptech.glide.Glide;
import com.google.android.gms.location.*;
import com.google.android.gms.tasks.CancellationTokenSource;

import org.json.JSONObject;

import java.io.File;
import java.io.IOException;

import okhttp3.*;

public class MainActivity extends AppCompatActivity {

    // Emulator: 10.0.2.2 ; real device: your PC's LAN IP, e.g. http://192.168.1.5:5000
    private static final String SERVER_URL = "http://10.0.2.2:5000";

    private ImageView imagePreview;
    private TextView resultText;
    private ProgressBar progress;
    private File photoFile;
    private Uri photoUri;
    private FusedLocationProviderClient locationClient;
    private final OkHttpClient http = new OkHttpClient();

    private final ActivityResultLauncher<String[]> permissionLauncher =
            registerForActivityResult(new ActivityResultContracts.RequestMultiplePermissions(),
                    r -> { if (hasPermissions()) launchCamera(); else toast("Camera & location permissions are required"); });

    private final ActivityResultLauncher<Uri> cameraLauncher =
            registerForActivityResult(new ActivityResultContracts.TakePicture(), ok -> {
                if (ok) {
                    Glide.with(this).load(photoFile).into(imagePreview);
                    fetchLocationAndUpload();
                }
            });

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_main);
        imagePreview = findViewById(R.id.imagePreview);
        resultText = findViewById(R.id.resultText);
        progress = findViewById(R.id.progress);
        locationClient = LocationServices.getFusedLocationProviderClient(this);

        findViewById(R.id.btnCapture).setOnClickListener(v -> {
            if (hasPermissions()) launchCamera();
            else permissionLauncher.launch(new String[]{Manifest.permission.CAMERA, Manifest.permission.ACCESS_FINE_LOCATION});
        });
        findViewById(R.id.btnMap).setOnClickListener(v -> startActivity(new Intent(this, MapsActivity.class)));
    }

    private boolean hasPermissions() {
        return checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED
                && checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED;
    }

    private void launchCamera() {
        try {
            photoFile = File.createTempFile("road_", ".jpg", getCacheDir());
        } catch (IOException e) { toast("Cannot create file"); return; }
        photoUri = FileProvider.getUriForFile(this, getPackageName() + ".fileprovider", photoFile);
        cameraLauncher.launch(photoUri);
    }

    private void fetchLocationAndUpload() {
        progress.setVisibility(View.VISIBLE);
        resultText.setText("Getting location...");
        try {
            locationClient.getCurrentLocation(Priority.PRIORITY_HIGH_ACCURACY, new CancellationTokenSource().getToken())
                    .addOnSuccessListener(loc -> {
                        if (loc == null) { fail("GPS location unavailable. Turn on location and retry."); return; }
                        upload(loc.getLatitude(), loc.getLongitude());
                    })
                    .addOnFailureListener(e -> fail("Location error: " + e.getMessage()));
        } catch (SecurityException e) { fail("Location permission denied"); }
    }

    private void upload(double lat, double lng) {
        runOnUiThread(() -> resultText.setText("Analysing image..."));
        RequestBody body = new MultipartBody.Builder().setType(MultipartBody.FORM)
                .addFormDataPart("latitude", String.valueOf(lat))
                .addFormDataPart("longitude", String.valueOf(lng))
                .addFormDataPart("image", "road.jpg", RequestBody.create(photoFile, MediaType.parse("image/jpeg")))
                .build();
        Request req = new Request.Builder().url(SERVER_URL + "/report").post(body).build();

        http.newCall(req).enqueue(new Callback() {
            @Override public void onFailure(Call call, IOException e) { fail("Server error: " + e.getMessage()); }
            @Override public void onResponse(Call call, Response r) throws IOException {
                String s = r.body().string();
                try {
                    JSONObject o = new JSONObject(s);
                    String type = o.getString("damage_type");
                    String msg = type.equals("no_damage")
                            ? "No road damage detected."
                            : String.format("Damage: %s\nConfidence: %.0f%%\nLocation: %.5f, %.5f\n%s  %s\nReport saved.",
                                type.toUpperCase(), o.getDouble("confidence") * 100,
                                o.getDouble("latitude"), o.getDouble("longitude"),
                                o.getString("date"), o.getString("time"));
                    runOnUiThread(() -> { progress.setVisibility(View.GONE); resultText.setText(msg); });
                } catch (Exception e) { fail("Bad response: " + s); }
            }
        });
    }

    private void fail(String m) {
        runOnUiThread(() -> { progress.setVisibility(View.GONE); resultText.setText(m); });
    }

    private void toast(String m) { Toast.makeText(this, m, Toast.LENGTH_SHORT).show(); }
}
