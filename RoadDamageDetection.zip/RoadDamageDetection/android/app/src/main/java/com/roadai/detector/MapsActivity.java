package com.roadai.detector;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.maps.*;
import com.google.android.gms.maps.model.*;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;

public class MapsActivity extends AppCompatActivity implements OnMapReadyCallback {

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_maps);
        ((SupportMapFragment) getSupportFragmentManager().findFragmentById(R.id.map)).getMapAsync(this);
    }

    @Override
    public void onMapReady(GoogleMap map) {
        FirebaseFirestore.getInstance().collection("reports").get().addOnSuccessListener(snap -> {
            LatLng last = null;
            for (DocumentSnapshot d : snap.getDocuments()) {
                Double lat = d.getDouble("latitude"), lng = d.getDouble("longitude");
                if (lat == null || lng == null) continue;
                String type = d.getString("damage_type");
                last = new LatLng(lat, lng);
                map.addMarker(new MarkerOptions()
                        .position(last)
                        .title(type == null ? "damage" : type.toUpperCase())
                        .snippet(d.getString("date") + " " + d.getString("time"))
                        .icon(BitmapDescriptorFactory.defaultMarker(
                                "pothole".equals(type) ? BitmapDescriptorFactory.HUE_RED : BitmapDescriptorFactory.HUE_ORANGE)));
            }
            if (last != null) map.moveCamera(CameraUpdateFactory.newLatLngZoom(last, 14));
        });
    }
}
