# AI-Based Road Damage Detection System

Android app (Java) -> Flask API -> OpenCV preprocessing + CNN -> Firebase Firestore, with GPS + Google Maps.

## Flow
1. User captures a road photo in the app; GPS coordinates are read.
2. App uploads image + lat/lng to Flask `/report`.
3. Flask preprocesses the image (OpenCV), CNN predicts: `crack`, `pothole`, `no_damage`.
4. Flask saves image, label, confidence, location, date/time to Firestore.
5. Map screen shows all reports as markers.

## Backend setup
```
cd backend
pip install -r requirements.txt
# dataset layout: dataset/train/{crack,pothole,no_damage}/*.jpg  and dataset/val/...
python train.py                 # creates road_damage_model.h5
# put Firebase service account key at backend/serviceAccountKey.json
python app.py                   # runs on 0.0.0.0:5000
```
Public datasets: RDD2020/RDD2022, Kaggle "Pothole Detection" datasets.

## Android setup
1. Open `android/` in Android Studio (or copy the files into a new Empty Views project, package `com.roadai.detector`).
2. Add `google-services.json` (Firebase) to `android/app/`.
3. Put your Google Maps API key in `AndroidManifest.xml`.
4. In `MainActivity.java` set `SERVER_URL` (emulator: `http://10.0.2.2:5000`; real phone: your PC's LAN IP).
