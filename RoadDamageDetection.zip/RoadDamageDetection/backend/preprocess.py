import cv2
import numpy as np

IMG_SIZE = 128

def preprocess_image(path):
    """Read image, denoise, enhance contrast, resize, normalise -> (1,H,W,3)."""
    img = cv2.imread(path)
    if img is None:
        raise ValueError("Could not read image")
    img = cv2.GaussianBlur(img, (3, 3), 0)
    # CLAHE on the L channel improves visibility of cracks in poor light
    lab = cv2.cvtColor(img, cv2.COLOR_BGR2LAB)
    l, a, b = cv2.split(lab)
    l = cv2.createCLAHE(clipLimit=2.0, tileGridSize=(8, 8)).apply(l)
    img = cv2.cvtColor(cv2.merge((l, a, b)), cv2.COLOR_LAB2RGB)
    img = cv2.resize(img, (IMG_SIZE, IMG_SIZE))
    return np.expand_dims(img.astype("float32") / 255.0, axis=0)
