import tensorflow as tf
from tensorflow.keras import layers, models
from preprocess import IMG_SIZE

CLASSES = ["crack", "no_damage", "pothole"]  # alphabetical = folder order

train = tf.keras.utils.image_dataset_from_directory(
    "dataset/train", image_size=(IMG_SIZE, IMG_SIZE), batch_size=32, label_mode="categorical")
val = tf.keras.utils.image_dataset_from_directory(
    "dataset/val", image_size=(IMG_SIZE, IMG_SIZE), batch_size=32, label_mode="categorical")

model = models.Sequential([
    layers.Input((IMG_SIZE, IMG_SIZE, 3)),
    layers.Rescaling(1.0 / 255),
    layers.RandomFlip("horizontal"),
    layers.RandomRotation(0.1),
    layers.Conv2D(32, 3, activation="relu"), layers.MaxPooling2D(),
    layers.Conv2D(64, 3, activation="relu"), layers.MaxPooling2D(),
    layers.Conv2D(128, 3, activation="relu"), layers.MaxPooling2D(),
    layers.Flatten(),
    layers.Dense(128, activation="relu"),
    layers.Dropout(0.5),
    layers.Dense(len(CLASSES), activation="softmax"),
])
model.compile(optimizer="adam", loss="categorical_crossentropy", metrics=["accuracy"])
model.fit(train, validation_data=val, epochs=15)
model.save("road_damage_model.h5")
print("Saved road_damage_model.h5")
