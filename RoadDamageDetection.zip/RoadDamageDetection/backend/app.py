import os, uuid
from datetime import datetime
from flask import Flask, request, jsonify, send_from_directory
import numpy as np
import tensorflow as tf
import firebase_admin
from firebase_admin import credentials, firestore
from preprocess import preprocess_image

CLASSES = ["crack", "no_damage", "pothole"]
UPLOAD_DIR = "uploads"
os.makedirs(UPLOAD_DIR, exist_ok=True)

app = Flask(__name__)
model = tf.keras.models.load_model("road_damage_model.h5")
firebase_admin.initialize_app(credentials.Certificate("serviceAccountKey.json"))
db = firestore.client()

def predict(path):
    probs = model.predict(preprocess_image(path), verbose=0)[0]
    i = int(np.argmax(probs))
    return CLASSES[i], float(probs[i])

def save_upload(file):
    name = f"{uuid.uuid4().hex}.jpg"
    path = os.path.join(UPLOAD_DIR, name)
    file.save(path)
    return name, path

@app.route("/predict", methods=["POST"])
def predict_only():
    if "image" not in request.files:
        return jsonify(error="image required"), 400
    _, path = save_upload(request.files["image"])
    label, conf = predict(path)
    return jsonify(damage_type=label, confidence=conf)

@app.route("/report", methods=["POST"])
def report():
    if "image" not in request.files:
        return jsonify(error="image required"), 400
    try:
        lat = float(request.form["latitude"]); lng = float(request.form["longitude"])
    except (KeyError, ValueError):
        return jsonify(error="valid latitude and longitude required"), 400

    name, path = save_upload(request.files["image"])
    label, conf = predict(path)
    now = datetime.now()
    doc = {
        "damage_type": label,
        "confidence": conf,
        "latitude": lat,
        "longitude": lng,
        "image_url": request.host_url + "uploads/" + name,
        "date": now.strftime("%Y-%m-%d"),
        "time": now.strftime("%H:%M:%S"),
        "status": "pending",
    }
    if label != "no_damage":      # only store real damage reports
        db.collection("reports").add(doc)
    return jsonify(doc)

@app.route("/uploads/<name>")
def uploads(name):
    return send_from_directory(UPLOAD_DIR, name)

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000)
